import java.io.File
import java.io.PrintWriter

var numLinhas = -1
var numColunas = -1

var tabuleiroHumano : Array<Array<Char?>> = emptyArray()
var tabuleiroComputador : Array<Array<Char?>> = emptyArray()
var tabuleiroPalpitesDoHumano : Array<Array<Char?>> = emptyArray()
var tabuleiroPalpitesDoComputador : Array<Array<Char?>> = emptyArray()


// Função que verifica se o tamanho do tabuleiro é válido.
fun tamanhoTabuleiroValido (numLinhas : Int, numColunas : Int) : Boolean {
    return when {
        ((numLinhas == 4) && (numColunas == 4)) ||
                ((numLinhas == 5) && (numColunas == 5)) ||
                ((numLinhas == 7) && (numColunas == 7)) ||
                ((numLinhas == 8) && (numColunas == 8)) ||
                ((numLinhas == 10) && (numColunas == 10)) -> true
        else -> false }
}


// Função que processa as coordenadas fornecidas pelo usuário.
fun processaCoordenadas(coordenadas: String, numLinhas: Int, numColunas: Int): Pair<Int,Int>? {
    val caracteresValidos = when {
        (numLinhas in(1..5)) && (numColunas in(1..5)) -> 'E'
        (numLinhas in(6..7)) && (numColunas in(6..7 ))-> 'G'
        (numLinhas == 8) && (numColunas == 8) -> 'H'
        (numLinhas > 8) && (numColunas > 8) && (numLinhas <= 26) && (numColunas <= 26) -> ('A' + numColunas-1)
        else -> return null }

    return when {
        //Caso A
        (coordenadas.length == 3) && (coordenadas[2] in('A'..caracteresValidos)) &&
                (coordenadas[1] == ',') && (coordenadas[0] in('1'..'9')) -> Pair ((coordenadas[0].toString()).toInt(),coordenadas[2]-'A'+1)

        //Caso B
        (coordenadas.length == 4) && (coordenadas[3] in('A'..caracteresValidos)) &&
                (coordenadas[2] == ',') && (coordenadas[1] in('0'..'9')) && (coordenadas[0] in('1'..'9'))->
            if(coordenadas[0].isDigit() && coordenadas[1].isDigit()) {
                val numero = ((coordenadas[0]).toString() + (coordenadas[1]).toString()).toInt()
                return Pair(numero,coordenadas[3]-'A'+1)
            } else return null
        else -> null }
}


// Função que cria a legenda horizontal do tabuleiro.
fun criaLegendaHorizontal (numColunas: Int) : String {
    if (numColunas !in (1..26)) {
        return "''" }

    var legenda = ""
    var count = 0

    while (count < numColunas - 1) {
        legenda += ('A' + count)
        legenda += " | "
        count++ }

    legenda += ('A' + count)
    return legenda
}



fun criaTerreno (numLinhas: Int, numColunas: Int): String {

    // Lógica para criar a representação visual do tabuleiro.

    val horizontal = criaLegendaHorizontal(numColunas)
    val linhaSuperior = "| $horizontal |"

    var tabela = "\n$linhaSuperior\n"
    var numeroLinha = 1

    while (numeroLinha <= numLinhas) {
        tabela += "|"
        var letra = 'A'

        while (letra < 'A' + numColunas) {
            tabela += "   |"
            letra++ }

        tabela += " $numeroLinha\n"
        numeroLinha++ }

    return tabela
}



fun calculaNumNavios (numLinhas: Int, numColunas: Int): Array<Int> {
    // Lógica para calcular o número de navios com base no tamanho do tabuleiro.
    return when {
        ((numLinhas == 4) && (numColunas == 4)) -> arrayOf(2, 0, 0, 0)
        ((numLinhas == 5) && (numColunas == 5)) -> arrayOf(1, 1, 1, 0)
        ((numLinhas == 7) && (numColunas == 7)) -> arrayOf(2, 1, 1, 1)
        ((numLinhas == 8) && (numColunas == 8)) -> arrayOf(2, 2, 1, 1)
        ((numLinhas == 10) && (numColunas == 10)) -> arrayOf(3, 2, 1, 1)
        else -> arrayOf(0, 0, 0, 0) }
}


//FEITA
fun criaTabuleiroVazio(numLinhas: Int, numColunas: Int): Array<Array<Char?>> {
    // Lógica para criar um tabuleiro vazio com o tamanho especificado.
    val tabuleiro = Array(numLinhas) { arrayOfNulls<Char?>(numColunas) }
    var linha = 0

    while (linha < numLinhas) {
        var coluna = 0
        while (coluna < numColunas) {
            tabuleiro[linha][coluna] = null
            coluna++ }
        linha++ }

    if (numLinhas <= 0 || numColunas <= 0) {
        return arrayOf(arrayOf(null)) }

    return tabuleiro
}


//FEITA
fun coordenadaContida (tabuleiroVazio: Array<Array<Char?>>, linha: Int, coluna: Int): Boolean {
    // Lógica para verificar se a coordenada está dentro dos limites do tabuleiro.
    return (linha in 1..tabuleiroVazio.size) && (coluna in 1..tabuleiroVazio.size)
}


//FEITA
fun limparCoordenadasVazias (coordenadas: Array<Pair<Int, Int>>): Array<Pair<Int, Int>> {
    // Lógica para limpar as coordenadas vazias e remover duplicadas.
    var tamanho = 0
    for (element in coordenadas) {
        if (element != Pair(0,0)) {
            tamanho++ } }

    val coordenadasLimpas = Array(tamanho){Pair(1,1)}
    var par = 0
    for (posicao in coordenadas.indices) {
        if (coordenadas[posicao] != Pair(0,0)) {
            coordenadasLimpas[par] = coordenadas[posicao]
            par++ } }

    return coordenadasLimpas
}


//FEITA
fun juntarCoordenadas(coordenada1: Array<Pair<Int, Int>>, coordenada2: Array<Pair<Int, Int>>): Array<Pair<Int, Int>> {
    // Juntar as coordenadas por,ex (1,A)
    return coordenada1 + coordenada2
}


// Função que gera as coordenadas de um navio com base na posição, orientação e dimensão.
fun gerarCoordenadasNavio(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int): Array<Pair<Int, Int>> {
    // Lógica para gerar as coordenadas do navio com base nos parâmetros fornecidos.
    return when (dimensao) {
        1 -> if (linha in 1..tabuleiro.size && coluna in 1..tabuleiro[0].size) {
            arrayOf(Pair(linha, coluna))
        } else {
            emptyArray()
        }
        2 -> when (orientacao) {
            "E" -> if (linha in 1..tabuleiro.size && coluna + 1 in 1..tabuleiro[0].size) {
                arrayOf(Pair(linha, coluna), Pair(linha, coluna + 1))
            } else {
                emptyArray()
            }
            else -> emptyArray()
        }
        3, 4 -> when (orientacao) {
            "E" -> if (linha in 1..tabuleiro.size && coluna + 3 in 1..tabuleiro[0].size) {
                arrayOf(
                        Pair(linha, coluna),
                        Pair(linha, coluna + 1),
                        Pair(linha, coluna + 2),
                        Pair(linha, coluna + 3))
            } else {
                emptyArray()
            }
            else -> emptyArray()
        }
        else -> emptyArray()
    }
}


// // Função que gera as coordenadas da fronteira de um navio com base na posição, orientação e dimensão.
fun gerarCoordenadasFronteira(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int): Array<Pair<Int,Int>>{
    // Lógica para gerar as coordenadas da fronteira de um navio com base nos parâmetros fornecidos.

    var coordenadas = emptyArray<Pair<Int, Int>> ()
    when (orientacao) {
        "N" -> { when (dimensao) {
            1 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha, coluna-1), Pair(linha, coluna + 1), Pair(linha + 1, coluna-1),
                    Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) }
            2 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 2, coluna-1), Pair(linha - 2, coluna),
                    Pair(linha - 2, coluna + 1), Pair(linha-1, coluna-1), Pair(linha-1, coluna + 1), Pair(linha, coluna-1),
                    Pair(linha, coluna+1), Pair(linha + 1, coluna - 1), Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) }
            3 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 3, coluna-1), Pair(linha - 3, coluna),
                    Pair(linha - 3, coluna + 1), Pair(linha - 2, coluna-1), Pair(linha - 2, coluna + 1), Pair(linha-1, coluna-1),
                    Pair(linha-1, coluna + 1), Pair(linha, coluna-1), Pair(linha, coluna+1), Pair(linha + 1, coluna - 1),
                    Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) }
            4 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 4, coluna-1), Pair(linha - 4, coluna),
                    Pair(linha - 4, coluna + 1), Pair(linha - 3, coluna-1), Pair(linha - 3, coluna + 1), Pair(linha - 2, coluna-1),
                    Pair(linha - 2, coluna + 1), Pair(linha-1, coluna-1), Pair(linha-1, coluna + 1), Pair(linha, coluna-1),
                    Pair(linha, coluna+1), Pair(linha + 1, coluna - 1), Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) } } }
        "S" -> { when (dimensao) {
            1 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha, coluna-1), Pair(linha, coluna + 1), Pair(linha + 1, coluna-1),
                    Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) }
            2 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha + 2, coluna-1), Pair(linha + 2, coluna),
                    Pair(linha + 2, coluna + 1), Pair(linha + 1, coluna-1), Pair(linha + 1, coluna + 1), Pair(linha, coluna-1),
                    Pair(linha, coluna+1), Pair(linha - 1, coluna - 1), Pair(linha - 1, coluna), Pair(linha - 1, coluna + 1))) }
            3 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha + 3, coluna-1), Pair(linha + 3, coluna),
                    Pair(linha + 3, coluna + 1), Pair(linha + 2, coluna-1), Pair(linha + 2, coluna + 1), Pair(linha + 1, coluna-1),
                    Pair(linha + 1, coluna + 1), Pair(linha, coluna-1), Pair(linha, coluna+1), Pair(linha - 1, coluna - 1),
                    Pair(linha - 1, coluna), Pair(linha - 1, coluna + 1))) }
            4 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha + 4, coluna-1), Pair(linha + 4, coluna),
                    Pair(linha + 4, coluna + 1), Pair(linha + 3, coluna-1), Pair(linha + 3, coluna + 1), Pair(linha + 2, coluna-1),
                    Pair(linha + 2, coluna + 1), Pair(linha + 1, coluna-1), Pair(linha + 1, coluna + 1), Pair(linha, coluna-1),
                    Pair(linha, coluna+1), Pair(linha - 1, coluna - 1), Pair(linha - 1, coluna), Pair(linha - 1, coluna + 1))) } } }
        "E" -> { when (dimensao) {
            1 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha, coluna-1), Pair(linha, coluna + 1), Pair(linha + 1, coluna-1),
                    Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) }
            2 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha - 1, coluna + 2), Pair(linha, coluna-1), Pair(linha, coluna + 2),
                    Pair(linha + 1, coluna-1), Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1), Pair(linha + 1, coluna + 2))) }
            3 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha - 1, coluna + 2), Pair(linha - 1, coluna + 3), Pair(linha, coluna-1),
                    Pair(linha, coluna + 3), Pair(linha + 1, coluna-1), Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1),
                    Pair(linha + 1, coluna + 2), Pair(linha + 1, coluna + 3))) }
            4 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha - 1, coluna + 2), Pair(linha - 1, coluna + 3), Pair(linha-1,coluna+4),
                    Pair(linha, coluna-1), Pair(linha, coluna+4),Pair(linha+1,coluna-1),Pair(linha+1,coluna),Pair(linha+1,coluna+1),
                    Pair(linha + 1, coluna + 2), Pair(linha + 1, coluna + 3), Pair(linha + 1, coluna + 4))) } } }
        "O" -> { when (dimensao) {
            1 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna-1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna + 1), Pair(linha, coluna-1), Pair(linha, coluna + 1), Pair(linha + 1, coluna-1),
                    Pair(linha + 1, coluna), Pair(linha + 1, coluna + 1))) }
            2 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna+1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna - 1), Pair(linha - 1, coluna - 2), Pair(linha, coluna+1), Pair(linha, coluna - 2),
                    Pair(linha + 1, coluna+1), Pair(linha + 1, coluna), Pair(linha + 1, coluna - 1), Pair(linha + 1, coluna - 2))) }
            3 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna+1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna - 1), Pair(linha - 1, coluna - 2), Pair(linha - 1, coluna - 3), Pair(linha, coluna+1),
                    Pair(linha, coluna - 3), Pair(linha + 1, coluna+1), Pair(linha + 1, coluna), Pair(linha + 1, coluna - 1),
                    Pair(linha + 1, coluna - 2), Pair(linha + 1, coluna - 3))) }
            4 -> { coordenadas = juntarCoordenadas(coordenadas, arrayOf(Pair(linha - 1, coluna+1), Pair(linha - 1, coluna),
                    Pair(linha - 1, coluna - 1), Pair(linha-1,coluna-2),Pair(linha-1,coluna-3),Pair(linha-1,coluna-4),
                    Pair(linha,coluna+1),Pair(linha,coluna-4),Pair(linha+1,coluna+1),Pair(linha+1,coluna),Pair(linha+1,coluna-1),
                    Pair(linha + 1, coluna - 2), Pair(linha + 1, coluna - 3), Pair(linha + 1, coluna - 4))) } } } }
    coordenadas = limparCoordenadasVazias(coordenadas)
    var resultado = emptyArray<Pair<Int, Int>>()
    for (coordenada in coordenadas) {
        if (coordenadaContida(tabuleiro, coordenada.first, coordenada.second)) { resultado += coordenada } }
    return resultado
}
//FEITA
fun estaLivre(tabuleiro: Array<Array<Char?>>, coordenadas: Array<Pair<Int, Int>>): Boolean {
    //verifica se todas as coordenadas estão livres no tabuleiro.
    var livre = true

    for ((linha,coluna) in coordenadas) {
        if (!coordenadaContida(tabuleiro,linha,coluna)) {
            livre = false } }

    for ((linha,coluna) in coordenadas) {
        if (tabuleiro[linha - 1][coluna - 1] != null) {
            livre = false } }

    return livre
}


// Função que insere um navio simples no tabuleiro nas coordenadas especificadas.
fun insereNavioSimples(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, dimensao: Int): Boolean {
    if (dimensao !in 1..4 || linha !in 1..tabuleiro.size || coluna !in 1..tabuleiro[0].size) {
        return false
    }

    val coordenadasNavio = gerarCoordenadasNavio(tabuleiro, linha, coluna, "E", dimensao)
    val coordenadasFronteira = gerarCoordenadasFronteira(tabuleiro, linha, coluna, "E", dimensao)
    val coordenadasJuntas = juntarCoordenadas(coordenadasNavio, coordenadasFronteira)

    for ((i, j) in coordenadasJuntas) {
        if (i in 1..tabuleiro.size && j in 1..tabuleiro[0].size && tabuleiro[i - 1][j - 1] != null) {
            return false
        }
    }

    for ((i, j) in gerarCoordenadasNavio(tabuleiro, linha, coluna, "E", dimensao)) {
        tabuleiro[i - 1][j - 1] = ('0' + dimensao).toChar()
    }

    return true
}


//FEITA ALERTA
fun insereNavio(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int): Boolean {
    // inserir um navio no tabuleiro com orientação e dimensão específicas.

    val coordenadas1 = gerarCoordenadasNavio(tabuleiro, linha, coluna, orientacao, dimensao)
    val coordenadas2 = gerarCoordenadasFronteira(tabuleiro, linha, coluna, orientacao, dimensao)
    val coordenadasJuntas = juntarCoordenadas(coordenadas1, coordenadas2)

    if (linha - 1 >= 0 && coluna - 1 >= 0) {
        if (estaLivre(tabuleiro, coordenadasJuntas)) {
            when (orientacao) {
                "N" -> {
                    for (i in 1..dimensao) {
                        tabuleiro[linha - i][coluna - 1] = dimensao.toString()[0]
                    }
                }
                "S" -> {
                    for (i in 1..dimensao) {
                        tabuleiro[linha + i - 2][coluna - 1] = dimensao.toString()[0]
                    }
                }
                "E" -> {
                    for (i in 1..dimensao) {
                        tabuleiro[linha - 1][coluna + i - 2] = dimensao.toString()[0]
                    }
                }
                "O" -> {
                    for (i in 1..dimensao) {
                        tabuleiro[linha - 1][coluna - i] = dimensao.toString()[0]
                    }
                }
                else -> return false
            }
            return true
        }
    }
    return false
}


// Função que preenche o tabuleiro do computador com navios de acordo com a configuração fornecida.
fun preencheTabuleiroComputador(tabuleiro: Array<Array<Char?>>, configuracao: Array<Int>): Array<Array<Char?>> {
    val tamanhoTabuleiro = tabuleiro.size

    for (dimensao in configuracao.indices) {
        val quantidade = configuracao[dimensao]

        if (quantidade > 0) {
            repeat(quantidade) {
                var linha: Int
                var coluna: Int
                var orientacao: String

                do {
                    linha = (1..tamanhoTabuleiro).random()
                    coluna = (1..tamanhoTabuleiro).random()
                    orientacao = arrayOf("N", "S", "E", "O").random()
                } while (!insereNavio(tabuleiro, linha, coluna, orientacao, dimensao + 1))
            }
        }
    }

    return tabuleiro
}


// verifica se um navio está completo nas coordenadas especificadas no tabuleiro.
fun navioCompleto(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int): Boolean {
    if (!coordenadaContida(tabuleiro, linha, coluna)) {
        return false
    }

    val navio = tabuleiro[linha - 1][coluna - 1]

    if (navio in arrayOf('1', '2', '3', '4')) { // ALERTA
        var contVertical = 0
        for (element in tabuleiro) {
            if (element[coluna - 1] == navio) {
                contVertical++
            } else {
                contVertical = 0
            }
            if (contVertical == navio.toString().toInt() && navio.toString().toInt() > 0) {
                for (k in 0 until navio.toString().toInt()) {
                    if (!coordenadaContida(tabuleiro, linha + k, coluna)) {
                        return false
                    }
                }
                return true
            }
        }
        var contHorizontal = 0
        for (j in 0 until tabuleiro[0].size) {
            if (tabuleiro[linha - 1][j] == navio) {
                contHorizontal++
            } else {
                contHorizontal = 0
            }

            if (contHorizontal == navio.toString().toInt()  && navio.toString().toInt() > 0) {
                for (k in 0 until navio.toString().toInt()) {
                    if (!coordenadaContida(tabuleiro, linha, coluna + k)) {
                        return false
                    }
                }
                return true
            }
        }
    }
    return false
}


// Função que obtém o mapa do tabuleiro para visualização com base em um valor booleano que indica se deve mostrar os navios (true) ou não (false).
fun obtemMapa(tabuleiro: Array<Array<Char?>>, valor: Boolean): Array<String>{
    var caracter: String
    val mapa = Array(tabuleiro.size+1){""}
    if (valor) {
        mapa[0] = "| ${criaLegendaHorizontal(tabuleiro[0].size)} |"
        for (linha in 1 ..tabuleiro.size) {
            caracter = ""
            for (coluna in 1 ..tabuleiro[0].size) {
                when {
                    tabuleiro[linha-1][coluna-1] == null -> caracter += "| ~ "
                    tabuleiro[linha-1][coluna-1] == '1' -> caracter += "| 1 "
                    tabuleiro[linha-1][coluna-1] == '2' -> caracter += "| 2 "
                    tabuleiro[linha-1][coluna-1] == '3' -> caracter += "| 3 "
                    tabuleiro[linha-1][coluna-1] == '4' -> caracter += "| 4 "
                }
            }
            mapa[linha] = "$caracter| $linha"
        }
    }else {
        mapa[0] = "| ${criaLegendaHorizontal(tabuleiro[0].size)} |"
        for (linha in 1..tabuleiro.size) {
            caracter = ""
            for (coluna in 1..tabuleiro[0].size) {
                when {
                    tabuleiro[linha - 1][coluna - 1] == null -> caracter += "| ? "
                    tabuleiro[linha - 1][coluna - 1] == 'X' -> caracter += "| X "
                    tabuleiro[linha - 1][coluna - 1] == '1' -> {
                        caracter += if (navioCompleto(tabuleiro, linha, coluna)) {
                            "| 1 "
                        } else "| \u2081 "
                    }
                    tabuleiro[linha - 1][coluna - 1] == '2' -> {
                        caracter += if (navioCompleto(tabuleiro, linha, coluna)) {
                            "| 2 "
                        } else "| \u2082 "
                    }
                    tabuleiro[linha - 1][coluna - 1] == '3' -> {
                        caracter += if (navioCompleto(tabuleiro, linha, coluna)) {
                            "| 3 "
                        } else "| \u2083 "
                    }
                    tabuleiro[linha - 1][coluna - 1] == '4' -> {
                        caracter += if (navioCompleto(tabuleiro, linha, coluna)) {
                            "| 4 "
                        } else "| \u2084 "
                    }
                }
            }
            mapa[linha] = "$caracter| $linha"
        }
    }
    return mapa
}


// Função que realiza o lançamento de um tiro no tabuleiro do computador.
fun lancarTiro(tabuleiroRealComputador: Array<Array<Char?>>, tabuleiroPalpitesDoHumano: Array<Array<Char?>>, coordenadas: Pair<Int, Int>): String {
    val linha = coordenadas.first - 1
    val coluna = coordenadas.second - 1

    if (coordenadaContida(tabuleiroRealComputador, coordenadas.first, coordenadas.second)) {
        val navio = tabuleiroRealComputador[linha][coluna]
        if (navio == null && tabuleiroPalpitesDoHumano[linha][coluna] == '?') {
            val naviosFaltaAfundar = calculaNaviosFaltaAfundar(tabuleiroPalpitesDoHumano)
            return "Falta afundar: " +
                    "${naviosFaltaAfundar[0]} porta-aviões(s); " +
                    "${naviosFaltaAfundar[1]} navio-tanque(s); " +
                    "${naviosFaltaAfundar[2]} contratorpedeiro(s); " +
                    "${naviosFaltaAfundar[3]} submarino(s)"
        } else {
            when (navio) {
                null -> tabuleiroPalpitesDoHumano[linha][coluna] = 'X' // Água
                '1' -> tabuleiroPalpitesDoHumano[linha][coluna] = '1' // Submarino
                '2' -> tabuleiroPalpitesDoHumano[linha][coluna] = '2' // Contra-Torpedeiro
                '3' -> tabuleiroPalpitesDoHumano[linha][coluna] = '3' // Navio-Tanque
                '4' -> tabuleiroPalpitesDoHumano[linha][coluna] = '4' // Porta-Aviões
            }
            // Parte do tabuleiro de palpites
            when (tabuleiroPalpitesDoHumano[linha][coluna]) {
                'X' -> return "Agua."
                '1' -> return "Tiro num submarino."
                '2' -> return "Tiro num contra-torpedeiro."
                '3' -> return "Tiro num navio-tanque."
                '4' -> return "Tiro num porta-aviões."
            } } }
    return "Coordenadas inválidas"
}



//gera coordenadas de tiro aleatórias para o computador
fun geraTiroComputador(tabuleiro: Array<Array<Char?>>): Pair<Int, Int> {
    var coordenada: Pair<Int, Int>
    do {
        coordenada = Pair((1..tabuleiro.size).random(), (1..tabuleiro[0].size).random())
    } while (!coordenadaContida(tabuleiro, coordenada.first, coordenada.second) || tabuleiro[coordenada.first - 1][coordenada.second - 1] != null)

    return coordenada
}


//conta o número de navios de uma determinada dimensão presentes no tabuleiro.
fun contarNaviosDeDimensao(tabuleiro: Array<Array<Char?>>, dimensao: Int): Int {
    var count = 0

    for (linha in 1..tabuleiro.size) {
        for (coluna in 1..tabuleiro[0].size) {
            val navio = tabuleiro[linha - 1][coluna - 1]

            if (navio == dimensao.toString()[0]) {
                var navioCompleto = true

                var aaa = 0
                while (aaa < dimensao && navioCompleto) {
                    if (!coordenadaContida(tabuleiro, linha + aaa, coluna) || tabuleiro[linha - 1 + aaa][coluna - 1] != navio) {
                        navioCompleto = false
                    }

                    if (!coordenadaContida(tabuleiro, linha, coluna + aaa) || tabuleiro[linha - 1][coluna - 1 + aaa] != navio) {
                        navioCompleto = false
                    }

                    aaa++
                }

                if (navioCompleto) {
                    count++
                }
            }
        }
    }
    return count
}



// verifica se o jogador venceu o jogo, ou seja, se todos os navios foram afundados.
fun venceu(tabuleiro: Array<Array<Char?>>): Boolean {
    val numNavios = calculaNumNavios(tabuleiro.size, tabuleiro[0].size)

    for (dimensao in 1..4) {
        val numNaviosDimensao = numNavios[dimensao - 1]
        val naviosAfundadosDimensao = contarNaviosDeDimensao(tabuleiro, dimensao)

        if (numNaviosDimensao != naviosAfundadosDimensao) {
            return false
        }
    }

    return true
}



//lê um jogo salvo de um arquivo e retorna o tabuleiro correspondente.
fun lerJogo (nomeFicheiro: String, tipoTabuleiro: Int): Array<Array<Char?>> {
    val ficheiroGravado = File(nomeFicheiro).readLines()
    numLinhas = ficheiroGravado[0][0].digitToInt()
    numColunas = ficheiroGravado[0][2].digitToInt()
    val linhasNoFicheiro = 3 * tipoTabuleiro + 1 + numLinhas * (tipoTabuleiro- 1) until 3 * tipoTabuleiro + 1 + numLinhas * tipoTabuleiro
    val tabuleiro = criaTabuleiroVazio(numLinhas,numColunas)
    var linha = linhasNoFicheiro.min()
    while(linha in linhasNoFicheiro){
        var coluna = 0
        var contaVirgulas = 0
        while (contaVirgulas < numColunas && coluna < ficheiroGravado [linha].length) {
            when (ficheiroGravado[linha] [coluna]){
                ',' -> contaVirgulas ++
                '1', '2', '3','4', 'X' -> tabuleiro[linha - linhasNoFicheiro.min()][contaVirgulas] = ficheiroGravado[linha][coluna] // ALERTA
            }
            coluna++
        }
        linha++
    }
    return tabuleiro
}


//grava os tabuleiros do jogo em um arquivo.
fun gravarTabuleiros(jogoGravado: PrintWriter, tabuleiro: Array<Array<Char?>>) {
    for(linha in tabuleiro.indices) {
        jogoGravado.println()
        for (coluna in tabuleiro[0].indices) {
            when (tabuleiro[linha][coluna]) {
                'X' -> jogoGravado.print("X")
                '1', '2', '3', '4' -> jogoGravado.print(tabuleiro[linha][coluna]) // ALERTA
            }
            if (coluna < tabuleiro[0].size - 1) {
                jogoGravado.print(",")
            }
        }
    }
}


//FEITA NAO MECHER
fun gravarJogo (nomeFicheiro: String, tabuleiroRealHumano: Array<Array<Char?>>, tabuleiroPalpitesHumano: Array<Array<Char?>>,
                tabuleiroRealComputador: Array<Array<Char?>>, tabuleiroPalpitesComputador: Array<Array<Char?>>) {
    val jogoGravado = File(nomeFicheiro).printWriter()
    jogoGravado.print("${tabuleiroRealHumano.size},${tabuleiroRealHumano[0].size}\n")
    jogoGravado.print("\nJogador\nReal")
    gravarTabuleiros(jogoGravado, tabuleiroRealHumano)
    jogoGravado.print("\n\nJogador\nPalpites")
    gravarTabuleiros(jogoGravado, tabuleiroPalpitesHumano)
    jogoGravado.print("\n\nComputador\nReal")
    gravarTabuleiros(jogoGravado, tabuleiroRealComputador)
    jogoGravado.print("\n\nComputador\nPalpites")
    gravarTabuleiros(jogoGravado, tabuleiroPalpitesComputador)
    jogoGravado.close()
    return
}
//calcula quantos navios de cada tipo ainda precisam ser afundados.
fun calculaNaviosFaltaAfundar(tabuleiroPalpites: Array<Array<Char?>>): Array<Int> {
    val configNavios = calculaNumNavios(tabuleiroPalpites.size, tabuleiroPalpites[0].size)

    val portaAvioesAfundar = configNavios[3] - contarNaviosDeDimensao(tabuleiroPalpites, 4)
    val naviosTanqueAfundar = configNavios[2] - contarNaviosDeDimensao(tabuleiroPalpites, 3)
    val contratorpedeirosAfundar = configNavios[1] - contarNaviosDeDimensao(tabuleiroPalpites, 2)
    val submarinosAfundar = configNavios[0] - contarNaviosDeDimensao(tabuleiroPalpites, 1)

    return arrayOf(
            if (portaAvioesAfundar > 0) portaAvioesAfundar else 0,
            if (naviosTanqueAfundar > 0) naviosTanqueAfundar else 0,
            if (contratorpedeirosAfundar > 0) contratorpedeirosAfundar else 0,
            if (submarinosAfundar > 0) submarinosAfundar else 0
    )
}

//calcula estatísticas do jogo, como número de jogadas, tiros certeiros e navios afundados.
fun calculaEstatisticas(tabuleiroPalpites: Array<Array<Char?>>): Array<Int> {
    var jogadas = 0
    var tirosCerteiros = 0
    var naviosAfundados = 0
    for (linha in tabuleiroPalpites.indices) {
        for(coluna in tabuleiroPalpites[linha].indices) {
            val palpites = tabuleiroPalpites[linha][coluna]
            if(palpites != null) {
                jogadas++
                if (palpites != 'X') {
                    tirosCerteiros ++
                    val coordeandas = Pair(linha + 1,coluna + 1)
                    if (navioCompleto(tabuleiroPalpites,coordeandas.first,coordeandas.second)) {
                        naviosAfundados++
                    }
                }
            }
        }
    }
    return arrayOf(jogadas,tirosCerteiros,naviosAfundados)
}



//escolher a opção de definir o tamanho do tabuleiro e o local dos navios.
fun opcao1() {
    println("\n> > Batalha Naval < <\n\nDefina o tamanho do tabuleiro:\nQuantas linhas?")
    var linhas = readln().toIntOrNull()
    while (linhas == null) {
        println("!!! Número de linhas invalidas, tente novamente\nQuantas linhas?")
        linhas = readln().toIntOrNull() }
    if (linhas == -1) { return }
    println("Quantas colunas?")
    var colunas = readln().toIntOrNull()
    while (colunas == null) {
        println("!!! Número de linhas colunas, tente novamente\nQuantas colunas?")
        colunas = readln().toIntOrNull() }
    if (colunas == -1) { return }
    numLinhas = linhas
    numColunas = colunas
    if (tamanhoTabuleiroValido(linhas, colunas)) { tabuleiroHumano = criaTabuleiroVazio(linhas,colunas)
        var mapa = obtemMapa(tabuleiroHumano,true)
        for (element in mapa){ println(element) }
        val numNavios = calculaNumNavios(tabuleiroHumano.size,tabuleiroHumano[0].size)
        var dimensao = 0
        var nomeNavio = ""
        for (i in numNavios.indices) { when (i) {
            0 -> { dimensao = 1
                nomeNavio = "submarino" }
            1 -> { dimensao = 2
                nomeNavio = "contra-torpedeiro" }
            2 -> { dimensao = 3
                nomeNavio = "navio-tanque" }
            3 -> { dimensao = 4
                nomeNavio = "porta-avioes" } }
            if (numNavios[i]>0){ for (j in 1..numNavios[i]){
                println("Insira as coordenadas de um $nomeNavio:\nCoordenadas? (ex: 6,G)")
                var coordenadas = readln()
                if (coordenadas == "-1") {
                    return }
                var coordenadasNavio = processaCoordenadas(coordenadas, linhas, colunas)
                if (dimensao == 1){ while (coordenadasNavio == null|| coordenadas == ""||
                        !insereNavio(tabuleiroHumano,coordenadasNavio.first,coordenadasNavio.second,"E",dimensao)) {
                    println("!!! Posicionamento invalido, tente novamente\nInsira as coordenadas de um $nomeNavio:\nCoordenadas? (ex: 6,G)")
                    coordenadas = readln()
                    if (coordenadas == "-1") { return }
                    coordenadasNavio = processaCoordenadas(coordenadas, linhas, colunas) } } else {
                    println("Insira a orientacao do navio:\nOrientacao? (N, S, E, O)")
                    var orientacao = readln()
                    if (orientacao == "-1"){ return }
                    while (coordenadasNavio == null|| coordenadas == ""||
                            !insereNavio(tabuleiroHumano,coordenadasNavio.first,coordenadasNavio.second,orientacao,dimensao)) {
                        println("!!! Posicionamento invalido, tente novamente\nInsira as coordenadas de um $nomeNavio:\nCoordenadas? (ex: 6,G)")
                        coordenadas = readln()
                        if (coordenadas == "-1") { return }
                        coordenadasNavio = processaCoordenadas(coordenadas, linhas, colunas)
                        println("Insira a orientacao do navio:\nOrientacao? (N, S, E, O)")
                        orientacao = readln()
                        if (orientacao == "-1"){ return } } }
                mapa = obtemMapa(tabuleiroHumano,true)
                for (element in mapa){ println(element) } } } }
        val configuracao = calculaNumNavios(linhas,colunas)
        tabuleiroComputador = criaTabuleiroVazio(linhas,colunas)
        tabuleiroComputador = preencheTabuleiroComputador(tabuleiroComputador,configuracao)
        println("Pretende ver o mapa gerado para o Computador? (S/N)")
        val opcaoEscolhida = readln()
        if (opcaoEscolhida=="S"){
            mapa = obtemMapa(tabuleiroComputador,true)
            for (element in mapa){
                println(element) }
            return } else if (opcaoEscolhida=="N"){
            return } }
    return }
//funçao dedicado ao jogo (2)
fun opcao2() {
    if (numLinhas == -1 && numColunas == -1) {
        println("!!! Tem que primeiro definir o tabuleiro do jogo, tente novamente")
        return
    } else {
        tabuleiroPalpitesDoHumano = criaTabuleiroVazio(numLinhas, numColunas)
        tabuleiroPalpitesDoComputador = criaTabuleiroVazio(numLinhas, numColunas)

        while (!venceu(tabuleiroPalpitesDoComputador) && !venceu(tabuleiroPalpitesDoHumano)) {
            val mapa = obtemMapa(tabuleiroPalpitesDoHumano, false)
            for (element in mapa) {
                println(element)
            }

            println("Indique a posição que pretende atingir\nCoordenadas? (ex: 6,G)")
            var coordenadas = readln()

            if (coordenadas == "-1") {
                return
            }

            if (coordenadas == "?") {
                // Mostrar estatísticas
                val naviosFaltaAfundar = calculaNaviosFaltaAfundar(tabuleiroPalpitesDoHumano)
                println("Falta afundar:${naviosFaltaAfundar[3]} submarino(s)")
                // Não usa continue aqui
            } else {
                var coordenadasNavio = processaCoordenadas(coordenadas, numLinhas, numColunas)

                while (coordenadasNavio == null) {
                    println("!!! Posicionamento invalido, tente novamente\nIndique a posição que pretende atingir\nCoordenadas? (ex: 6,G)")
                    coordenadas = readln()

                    if (coordenadas == "-1") {
                        return
                    }

                    coordenadasNavio = processaCoordenadas(coordenadas, numLinhas, numColunas)
                }

                val alvoAtingido = lancarTiro(tabuleiroComputador, tabuleiroPalpitesDoHumano, coordenadasNavio)

                if (!navioCompleto(tabuleiroPalpitesDoHumano, coordenadasNavio.first, coordenadasNavio.second)) {
                    println(">>> HUMANO >>>$alvoAtingido")
                } else {
                    println(">>> HUMANO >>>$alvoAtingido Navio ao fundo!")
                }
            }

            if (!venceu(tabuleiroPalpitesDoComputador) && !venceu(tabuleiroPalpitesDoHumano)) {
                val tiroComputador = geraTiroComputador(tabuleiroPalpitesDoComputador)
                println("Computador lancou tiro para a posicao $tiroComputador")
                val alvoAtingido = lancarTiro(tabuleiroHumano, tabuleiroPalpitesDoComputador, tiroComputador)

                if (!navioCompleto(tabuleiroPalpitesDoComputador, tiroComputador.first, tiroComputador.second)) {
                    println(">>> COMPUTADOR >>>$alvoAtingido")
                } else {
                    println(">>> COMPUTADOR >>>$alvoAtingido Navio ao fundo!")
                }

                println("Prima enter para continuar")
                readln()
            }
        }

        if (venceu(tabuleiroPalpitesDoHumano)) {
            println("PARABENS! Venceu o jogo!\nPrima enter para voltar ao menu principal")
            readln()
        } else {
            println("OPS! O computador venceu o jogo!\nPrima enter para voltar ao menu principal")
            readln()
        }
    }
}

//escolher para gravar o jogo
fun opcao3(
        tabuleiroHumano: Array<Array<Char?>>,
        tabuleiroPalpitesDoHumano: Array<Array<Char?>>,
        tabuleiroComputador: Array<Array<Char?>>,
        tabuleiroPalpitesDoComputador: Array<Array<Char?>>
) {


    println("Introduza o nome do ficheiro (ex: jogo.txt)")
    val nomeArquivo = readLine() ?: return

    gravarJogo(
            nomeArquivo,
            tabuleiroHumano,
            tabuleiroPalpitesDoHumano,
            tabuleiroComputador,
            tabuleiroPalpitesDoComputador
    )

    println("Tabuleiro ${tabuleiroHumano[0].size}x${tabuleiroHumano.size} gravado com sucesso")
}

fun opcao4() {
}




//FEITA
fun menuInicial(){
    while (true) {
        println("\n> > Batalha Naval < <\n\n1 - Definir Tabuleiro e Navios\n2 - Jogar\n3 - Gravar\n4 - Ler\n0 - Sair\n")

        var opcaoInicial : Int?

        do {
            opcaoInicial = readln().toIntOrNull()
            if (opcaoInicial == null || opcaoInicial > 4 || opcaoInicial < -1) {
                println("!!! Opcao invalida, tente novamente") }
        } while (opcaoInicial == null || opcaoInicial > 4 || opcaoInicial < -1)

        when (opcaoInicial) {
            0 -> return
            1 -> opcao1()
            2 -> opcao2()
            3 -> opcao3(tabuleiroHumano,tabuleiroPalpitesDoHumano,tabuleiroComputador,tabuleiroPalpitesDoComputador)
            4 -> opcao4()
        }
    }
}



fun main() {
    menuInicial()

}
